package user;
import org.w3c.dom.Document;

import java.lang.System;

public class MyDomTransformer {
    public void transform (Document xmlDocument) {
        // Do nothing.
        System.out.println("Hello, errorneous XML document.");
    }
}
